#pragma once

#ifdef __cplusplus
extern "C" {
#endif

// Register ping functions
void register_csi_recv(void);

#ifdef __cplusplus
}
#endif
